"""FreeCAD 1.1 Python: compact fit coupons, not a complete mount.
Run with C:/Program Files/FreeCAD 1.1/bin/python.exe.
Existing STEP threads are reused; no replacement thread standard is invented.
"""
from pathlib import Path
import math, json, hashlib
import FreeCAD as App
import Part, Mesh, MeshPart

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'TESTS'
SOURCE_STEP = ROOT/'STEP_EDITABLE/02_clamp_screw_10x2p5_42mm.step'
if not SOURCE_STEP.exists():
    SOURCE_STEP = OUT/'SOURCE_INPUTS/02_clamp_screw_10x2p5_42mm.step'
V = App.Vector
parts = []
doc = App.newDocument('TestPlate_v1')

def box(x,y,z,at=(0,0,0)):
    return Part.makeBox(x,y,z,V(*at))

def polygon(points,h):
    pts=[V(x,y,0) for x,y in points]
    return Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,h))

def moved(s,xyz):
    s=s.copy(); s.translate(V(*xyz)); return s

def label(s,letter,x,y,z):
    # Stroke letters: 0.8 mm strokes, 0.6 mm high, fused to the part.
    strokes={'A':[(0,0,0,3),(2,0,2,3),(0,3,2,3),(0,1.5,2,1.5)],
    'B':[(0,0,0,3),(0,0,2,0),(0,1.5,2,1.5),(0,3,2,3),(2,0,2,3)],
    'C':[(0,0,0,3),(0,0,2,0),(0,3,2,3)],
    'P':[(0,0,0,3),(0,3,2,3),(2,1.5,2,3),(0,1.5,2,1.5)],
    'J':[(0,0,2,0),(2,0,2,3),(0,0,0,1)],
    'N':[(0,0,0,3),(2,0,2,3),(0,1.5,2,1.5)],
    'H':[(0,0,0,3),(2,0,2,3),(0,1.5,2,1.5)]}
    for a,b,c,d in strokes[letter]:
        s=s.fuse(box(abs(c-a)+.8,abs(d-b)+.8,.65,(x+min(a,c),y+min(b,d),z-.05)))
    return s.removeSplitter()

def add(name,s,x,y,notes):
    s=s.removeSplitter()
    assert s.isValid() and len(s.Solids)==1,(name,'invalid CAD',len(s.Solids))
    mesh=MeshPart.meshFromShape(Shape=s,LinearDeflection=.035,AngularDeflection=.12,Relative=False)
    b=mesh.BoundBox
    offset=(x-b.XMin,y-b.YMin,-b.ZMin)
    s=moved(s,offset)
    mesh=MeshPart.meshFromShape(Shape=s,LinearDeflection=.035,AngularDeflection=.12,Relative=False)
    mesh.write(str(OUT/(name+'.stl')))
    obj=doc.addObject('PartDesign::Feature',name); obj.Label=name; obj.Shape=s
    b=mesh.BoundBox
    parts.append({'name':name,'shape':s,'mesh':mesh,'bounds':[b.XMin,b.YMin,b.ZMin,b.XMax,b.YMax,b.ZMax], 'notes':notes})
    print(name,round(s.Volume,1),flush=True)

# 8 mm sections of wraparound 2020 clips; cross-section is on the bed.
# Each jaw has a 20 mm flexing length; sloped lead-ins and 0.7 mm retaining tips.
for i,gap in enumerate((20.2,20.5,20.8)):
    t=1.2; h=21.6; w=gap+2*t
    pts=[(0,0),(w,0),(w,h),(w-t,h+.8),(w-t-.7,h-.6),
         (w-t,h-1.8),(w-t,t),(t,t),(t,h-1.8),
         (t+.7,h-.6),(t,h+.8),(0,h)]
    s=polygon(pts,6).fuse(box(7,5,6,(w/2-3.5,-4,0)))
    s=label(s,'ABC'[i],w/2-1.4,-3,6)
    add('Frame_'+ 'ABC'[i],s,22+i*33,22,f'20x20 assumption; internal gap {gap} mm; 6 mm section')

# Joint discs: 12 dog teeth, 30-degree indexing, loosen to disengage.
# A 50 mm load-hole radius makes the torque test repeatable.
def joint():
    s=Part.makeCylinder(15,3.2)
    s=s.fuse(box(50,10,3.2,(0,-5,0))).fuse(Part.makeCylinder(5,3.2,V(50,0,0)))
    for i in range(12):
        a=math.radians(i*30+.6); b=math.radians(i*30+14.4)
        pts=[]
        for r,angles in ((14.6,[a+(b-a)*j/5 for j in range(6)]),(9.0,[b-(b-a)*j/5 for j in range(6)])):
            pts += [(r*math.cos(k),r*math.sin(k)) for k in angles]
        s=s.fuse(moved(polygon(pts,1.25),(0,0,3.15)))
    s=s.cut(Part.makeCylinder(5.25,8,V(0,0,-1)))
    s=s.cut(Part.makeCylinder(2.5,6,V(50,0,-1)))
    s=s.cut(box(20,4,6,(23,-2,-1)))
    return label(s,'J',17,-1.8,3.2)
add('Joint_1',joint(),22,62,'3.2 mm plate + 1.2 mm dog teeth; load hole 50 mm from axis')
add('Joint_2',joint(),104,62,'Flip to oppose faces; arms align at 0 degrees; reindex in 30-degree steps')

# Shorten existing V5 long screw without changing its pitch or flank geometry.
male=Part.read(str(SOURCE_STEP))
envelope=box(40,40,18.8,(-20,-20,0)).fuse(Part.makeCone(5.2,3.6,1.2,V(0,0,18.8)))
male=male.common(envelope)
add('Joint_screw',male,124,22,'Existing V5 long male STEP shortened to 20 mm overall; tapered entrance; head down')

# Derive female cutter directly from the reused male: old nut did not clear it.
# XY-only factor adds 0.37-0.48 mm radial clearance and preserves axial pitch.
source_screw=Part.read(str(SOURCE_STEP))
cavity=source_screw.common(box(20,20,10,(-10,-10,10)))
cavity=moved(cavity,(0,0,-10))
mat=App.Matrix(); mat.A11=1.10; mat.A22=1.10
cavity=cavity.transformGeometry(mat)
nut=Part.makeCylinder(10,6.4).cut(cavity)
# Explicit flank relief: a radial change alone left thin helical interference.
# Shifted cutter copies add 0.15 mm relief per axial flank, without changing pitch.
nut=nut.cut(moved(cavity,(0,0,-.15))).cut(moved(cavity,(0,0,.15)))
# Entry/exit bevels ease alignment and remove first-layer intrusion at bore edge.
nut=nut.cut(Part.makeCone(6.2,4.2,2,V(0,0,0)))
nut=nut.cut(Part.makeCone(4.2,6.2,2,V(0,0,4.4)))
nut=label(nut,'N',6,-1.7,6.4)
add('Joint_nut',nut,153,22,'Existing male-derived cutter; 10% radial enlargement plus +/-0.15 mm axial flank relief; pitch unchanged')

# Short edge cross sections follow the v6 opening dimensions, not full cradles.
# These are local fit tests; position them along the real edge to assess controls.
def grip(clear,letter):
    t=1.6; depth=8
    pts=[(0,0),(clear+2*t,0),(clear+2*t,depth),(clear+t-.6,depth),
         (clear+t-.6,depth-1.2),(clear+t,depth-1.8),(clear+t,t),
         (t,t),(t,depth),(0,depth)]
    s=polygon(pts,6).fuse(box(7,4,6,(clear/2-2,-3,0)))
    return label(s,letter,clear/2-.6,-2.5,6)
add('Pixel_P',grip(13.8,'P'),22,111,'v6 13.8 mm case-depth envelope; 0.6 mm lip; short edge coupon')
add('Cardputer_C',grip(20.4,'C'),57,111,'ADV 19.6 nominal + 0.8 mm overall clearance; local contour must be tested')

# Small T-slide connector concept preserves the v6 slide-interface principle.
# Slot printed upright, with closed floor; positive transverse keeper pin.
profile=[(-6,-3),(6,-3),(6,0),(3,0),(3,4),(-3,4),(-3,0),(-6,0)]
slot=[(-6.3,-3.3),(6.3,-3.3),(6.3,.3),(3.3,.3),(3.3,4.5),(-3.3,4.5),(-3.3,.3),(-6.3,.3)]
female=box(18,11,9.6,(-9,-5,0)).cut(moved(polygon(slot,14),(0,0,1.6)))
female=female.cut(box(24,3,3,(-12,-2.4,5)))
female=female.fuse(box(7,5,9.6,(-3.5,-9,0)))
female=label(female,'H',-1.4,-8.5,9.6)
add('Head_female',female,99,113,'T-slot 0.30 mm per-side gap; floor 1.6; square cross-pin hole bridges 3 mm')
male=polygon(profile,11)
male=male.cut(box(24,3,3,(-12,-2.4,3.4)))
add('Head_male',male,129,113,'Insert lower end until floor; keeper holes align at assembled z5')
pin=polygon([(0,-.25),(27,0),(27,2.6),(0,2.85)],2.6).fuse(box(2,5.6,2.6,(-1,-1.5,0)))
add('Head_pin',pin,153,113,'Tapered keeper: 2.6 to 3.1 mm width, 2.6 high; push until snug, head stays proud; check migration')

doc.recompute()
doc.saveAs(str(OUT/'TestPlate_v1.FCStd'))
Part.makeCompound([p['shape'] for p in parts]).exportStep(str(OUT/'TestPlate_v1.step'))
allmesh=Mesh.Mesh()
for p in parts: allmesh.addMesh(p['mesh'])
allmesh.write(str(OUT/'TestPlate_v1.stl'))
report=[]
for p in parts:
    row={k:v for k,v in p.items() if k not in ('mesh','shape')}
    row['cad_valid']=p['shape'].isValid(); row['solid_count']=len(p['shape'].Solids)
    row['volume_mm3']=p['shape'].Volume
    row['sha256']=hashlib.sha256((OUT/(p['name']+'.stl')).read_bytes()).hexdigest()
    report.append(row)
(OUT/'CAD_MANIFEST.json').write_text(json.dumps(report,indent=2))
print('EXPORTED',len(parts),'parts',allmesh.BoundBox,flush=True)
