from pathlib import Path
import json
import FreeCAD as A
import Part,MeshPart
P=Path(__file__).resolve().parent
doc=A.openDocument(str(P/'TestPlate_v1.FCStd'))
V=A.Vector
def shift(name,delta):
    s=doc.getObject(name).Shape.copy();s.translate(V(*delta));return s
# Mesh-normalised positions in build_test_plate.py, with roundoff <0.013 mm.
screw=shift('Joint_screw',(-133.9955244,-31.99888134,0))
nut=shift('Joint_nut',(-162.9955244,-31.99888134,11.6))
angles=[]
for i in [129.6,125,135]:
    q=screw.copy();q.rotate(V(),V(0,0,1),i)
    angles.append((i,q.common(nut).Volume))
angle,overlap=min(angles,key=lambda x:x[1])
assert overlap<.001,('thread interference',angle,overlap)
# Trace two turns on the existing helix, checking axial translation sign.
paths=[]
for sign in (-1,1):
    samples=[]
    for dz in (0,.625,1.25,1.875,2.5):
        q=screw.copy();q.rotate(V(),V(0,0,1),angle+sign*dz/2.5*360)
        q.translate(V(0,0,dz));samples.append(q.common(nut).Volume)
    paths.append({'rotation_sign':sign,'intersection_mm3':samples})
best=min(paths,key=lambda x:max(x['intersection_mm3']))
assert max(best['intersection_mm3'])<.001,('thread motion interference',paths)
joint1=shift('Joint_1',(-37,-77,0))
joint2=shift('Joint_2',(-119,-77,0))
joint2.rotate(V(),V(1,0,0),180);joint2.translate(V(0,0,7.6))
joint_overlap=joint1.common(joint2).Volume
assert joint_overlap<.001,('joint collision',joint_overlap)
female=shift('Head_female',(-108,-122,0))
male=shift('Head_male',(-135,-116,1.6))
head_overlap=female.common(male).Volume
assert head_overlap<.001,('connector collision',head_overlap)
pin=shift('Head_pin',(-169.5,-116.7,5.2))
pin_overlap=pin.common(female.fuse(male)).Volume
assert pin_overlap<.001,('keeper collision',pin_overlap)
# Reimport exchange format; one valid solid per printable part.
step=Part.read(str(P/'TestPlate_v1.step'))
assert step.isValid() and len(step.Solids)==12
report={'thread_best_angle_deg':angle,'thread_collision_mm3':overlap,'one_turn_axial_motion':best,'joint_interference_mm3':joint_overlap,'head_interference_mm3':head_overlap,'keeper_interference_mm3':pin_overlap,'step_roundtrip_valid':True,'step_solid_count':12,'limitation':'Geometric assembly checks only; physical friction, PLA strength, creep and printer tolerances remain untested.'}
(P/'ASSEMBLY_VALIDATION.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
