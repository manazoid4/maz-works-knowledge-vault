from pathlib import Path
import json
import FreeCAD,Mesh
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).resolve().parent
im=Image.new('RGB',(1100,780),'#f2f3f1');d=ImageDraw.Draw(im)
font=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',18)
scale=5;ox=-30;oy=740
for row in json.loads((p/'CAD_MANIFEST.json').read_text()):
    m=Mesh.Mesh(str(p/(row['name']+'.stl')))
    for f in sorted(m.Facets,key=lambda f:sum(v[2] for v in f.Points)):
        z=sum(v[2] for v in f.Points)/3;shade=int(100+min(z,20)*5)
        d.polygon([(ox+v[0]*scale,oy-v[1]*scale) for v in f.Points],fill=(50,shade,160))
    b=row['bounds'];d.text((ox+b[0]*scale,oy-b[1]*scale+6),row['name'],fill='black',font=font)
d.text((40,20),'TestPlate v1 — 159 × 106 mm — 12 separate parts',fill='black',font=font)
im.save(p/'PLATE_MAP.png')
