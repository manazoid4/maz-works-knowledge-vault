from pathlib import Path
import sys, json, hashlib, math
sys.path.insert(0,r'C:\Users\manaz\Desktop\3d print\Cardputer\Mount\validation-tools')
import trimesh
import numpy as np
OUT=Path(__file__).resolve().parent
def components(m):
    parent=list(range(len(m.faces)))
    def root(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]; x=parent[x]
        return x
    for a,b in m.face_adjacency:
        parent[root(a)]=root(b)
    return len({root(i) for i in range(len(parent))})
manifest=json.loads((OUT/'CAD_MANIFEST.json').read_text())
results=[]; meshes=[]
for row in manifest:
    m=trimesh.load_mesh(OUT/(row['name']+'.stl'))
    assert m.is_watertight and m.is_winding_consistent and m.is_volume,row['name']
    assert components(m)==1,row['name']
    assert np.all(m.bounds[0]>=-1e-5) and np.all(m.bounds[1,:2]<=220),row['name']
    meshes.append(m)
    results.append(dict(name=row['name'],watertight=True,winding_consistent=True,components=1,volume_mm3=float(m.volume),bounds_mm=m.bounds.tolist(),triangles=len(m.faces)))
minimum=1e6
for i,a in enumerate(meshes):
    for b in meshes[i+1:]:
        gap=np.maximum(np.maximum(a.bounds[0,:2]-b.bounds[1,:2],b.bounds[0,:2]-a.bounds[1,:2]),0)
        d=float(np.linalg.norm(gap)); minimum=min(minimum,d)
        assert d>=6,('spacing',i,d)
plate=trimesh.load_mesh(OUT/'TestPlate_v1.stl')
assert plate.is_volume and plate.is_watertight and components(plate)==12
report=dict(parts=results,component_count=12,watertight=True,bed_mm=[220,220],bounds_mm=plate.bounds.tolist(),size_mm=plate.extents.tolist(),min_bbox_separation_mm=minimum,solid_volume_mm3=float(plate.volume),solid_PLA_upper_estimate_g=float(plate.volume*.00124),sha256=hashlib.sha256((OUT/'TestPlate_v1.stl').read_bytes()).hexdigest())
(OUT/'MESH_VALIDATION.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='parts'},indent=2))
