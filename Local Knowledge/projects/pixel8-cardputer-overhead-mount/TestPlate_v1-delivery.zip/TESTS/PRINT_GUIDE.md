# Pixel8-Cardputer-Overhead-Mount — TestPlate v1

Print this test plate only. The old screw/hole pair is NOT validated: it was tight and would not engage fully. Do not print the earlier overnight 3MF or full arm yet.

## Files to open

- `TestPlate_v1.stl`: all 12 separate parts already arranged and oriented in one model.
- `TestPlate_v1.step`: editable exchange CAD, 12 solid bodies.
- `TestPlate_v1.FCStd`: editable FreeCAD document with named bodies.
- `build_test_plate.py`: parameterised construction source, FreeCAD 1.1 Python.
- `TestPlate_v1_SLICED_ESTIMATE.3mf`: Orca toolpath estimate, not a verified machine-specific print job. Select your current working Ender 5 printer profile and re-slice before export.
- `MESH_VALIDATION.json`, `ASSEMBLY_VALIDATION.json`, `SLICE_SUMMARY.json`: measured geometry and slicer evidence.

The complete plate is approximately 159 x 106 x 20 mm, inside a 220 x 220 mm bed, with over 9 mm separation. No common plastic base is printed. Budget approximately **2 hours, 15 g PLA**, plus heating. This misses the preferred 90-minute goal, but is not an overnight build. The exact latest toolpath estimate is in `SLICE_SUMMARY.json`; actual printer timing may differ.

## OrcaSlicer: quickest route

1. Start a new project. Select the Ender 5 printer profile that already works on your machine, with a 0.4 mm nozzle and 220 x 220 mm usable bed. The nearby `3d print` folder contains a Klipper DRAFT profile with custom start macros: do not substitute that for a working profile.
2. Import `TestPlate_v1.stl` in millimetres, at **100% scale**. Keep the entire imported arrangement. Keep flat bottoms on the bed; **do not auto-orient, rotate individual parts, or scale to fit**. If Orca asks whether to treat it as one object, accept. There should be 12 separated pieces, not 12 additional copies of the plate.
3. Use the settings below, then Slice. Confirm all pieces appear from layer 1, the screw stands on its head, the joint teeth face up, and both connector slot and screw/nut axes are vertical.
4. Check that supports are absent and no component is outside the bed. Check Preview at the connector cross-pin holes: these use a short approximately 3 mm bridge, not a long unsupported roof.
5. Export G-code from your current printer profile. Transfer and start it using your usual proven workflow. Let everything cool before removing or testing.

| Setting | Value used for estimate |
|---|---|
| Nozzle / layer / first layer | 0.4 / 0.20 / 0.20 mm |
| Normal / first-layer line width | 0.45 / 0.45 mm |
| Walls | 3 |
| Top / bottom | 4 / 4 layers |
| Infill | 15% gyroid |
| Outer / inner walls | 30 / 50 mm/s |
| Infill / internal solid / top | 60 / 50 / 35 mm/s |
| First layer | 20 mm/s |
| Travel / acceleration | 100 mm/s / 500 mm/s2 |
| Supports / raft / brim / skirt | Off / off / off / off |
| Sequence | By layer, never by object |
| XY hole / contour compensation | 0 / 0 mm; clearance is in CAD |
| Elephant-foot compensation | 0.15 mm |
| Seam | Rear; inspect threads after print |
| PLA / bed | 205 / 60 C estimate; use your filament's proven temperature |
| Cooling | Fan off first layer, 100% thereafter; minimum layer time 8 s |
| Retraction / Z-hop | Estimate uses 5 mm at 30 mm/s / 0.2 mm; retain your proven retraction if different |

These are print assumptions, not a new printer calibration. A different working machine/filament profile can change the time estimate. No temperature, firmware, or printer hardware settings have been changed by this task.

## Physical tests and results to report

**Frame A/B/C** — short 6 mm sections, not complete mounts. Internal widths are A 20.2, B 20.5, C 20.8 mm. Test on the actual intended extrusion with printer idle. Try C first, then B, then A. Choose the tightest that snaps on by hand, resists sliding and pulling off, and can be removed without a crack or whitening. Repeat 10 times. These assume a nominal 20 x 20 mm exterior; they do not prove slot dimensions or full-mount load capacity. Report the winning letter, looseness, removal effort, and any damage.

**Joint screw + N nut** — the screw is shortened from the existing V5 long screw STEP with a tapered entrance. Its pitch is unchanged. The nut is newly derived from that male, with 0.37–0.48 mm radial enlargement and 0.15 mm relief on each axial flank. The old female geometry did not pass the virtual mating check. First test the new pair by hand, separate from the joint: start square, back-turn to locate the start, then turn through the entire nut. It is a through-hole, so it cannot simply bottom out. No pliers. Also try your old screw in the new nut separately, if it is the same V5 thread family; report differences, without assuming compatibility with unidentified old files.

**Joint pair J/J** — put the toothed faces together. Flip one piece over; the arms can initially point in the same direction. The faces index every 30 degrees. Insert the screw through both central holes and tighten the N nut by hand. The engaged stack is 7.6 mm thick. Loosen sufficiently to separate the teeth by at least 1.2 mm before changing the angle: this is a clamped indexed joint, not a mechanism to ratchet under load. Check usable movement, engagement, and play. Repeat loosen/move/tighten 30 times, then repeat the load test; inspect tooth wear and nut damage.

For a repeatable load test, securely hold one arm coupon and suspend a known mass from the other coupon's round end hole. The hole centre is **50 mm from the joint axis**. Keep the loaded lever horizontal. Work just above a padded table, without your phone underneath. Start with 250 g, then 500 g, then 1 kg if stable. Record mass, whether it slips, and drift after 10 minutes. One kilogram produces 0.491 Nm. The bare Pixel 8 is 187 g: at an illustrative 300 mm reach it produces 0.550 Nm before adding the case, head, or arm. Thus 1 kg at the coupon hole does NOT prove a complete 300 mm phone arm. If stable, 1.25 kg gives 0.613 Nm and 1.5 kg gives 0.736 Nm; stop on slipping, whitening, cracking or stripping. Final reach and total load remain to be designed after results.

**Pixel P** — short edge coupon, using the existing v6 13.8 mm depth envelope, with a small retaining lip. Try it on the real cased phone edge at the intended grip location. It should enter without forcing, avoid screen pressure, and resist sliding off the edge. Move it along the edge to identify button obstruction and record the safe location and available width. Report measured case thickness if possible and any loose gap. The case is unidentified: this coupon does not validate full holder width, camera-bar clearance, or full-phone retention by itself. Keep the phone supported during the test.

**Cardputer C** — short edge coupon, nominal 20.4 mm depth opening for the ADV's published 19.6 mm overall thickness. Test the actual local shell section: the ADV is not a solid rectangular block. Check snap/edge retention and removal; move the coupon to candidate grip locations and plug in the real USB-C cable, operate buttons/switches, and check SD access. Record where the grip can sit without obstruction. Full cradle dimensions and port placement are not established by this coupon alone.

**Head connector H + male + tapered pin** — insert the male's lower end down into the female T-slot until it rests on the floor. Align the cross holes. Insert the narrow end of the flat keeper pin through the side, then push only until snug. The taper increases from 2.6 to 3.1 mm in width, so the head is expected to stand proud; do not force it flush. Check pulling up, twisting, side play, and pin migration. Remove the pin and slide the male back out. Repeat 20 times and inspect wear. Report whether the pin stays put and whether removal remains possible by hand. This is a new shared-head test interface inspired by the v6 sliding approach; it is not claimed to fit the old full cradles.

## Scope and stop condition

All CAD, mesh and digital assembly checks are recorded, but none establishes physical strength, creep resistance or a perfect printer-specific fit. Only the test pieces have been generated. Report the fits above before any full arm, full holder, or overnight plate is designed.
