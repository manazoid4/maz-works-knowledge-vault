# Fit research — Pixel8-Cardputer-Overhead-Mount

Date: 2026-09-13. Scope: one compact fit-test plate; no complete arm or overnight plan.

## Existing work and correction to project truth

The user's latest physical result is **tight screw, incomplete engagement**. This supersedes the earlier description of a validated screw/thread pair. A mathematically valid model cannot establish perfect printer-specific fit.

Local `00_READ_ME_PRINT_ORDER.txt` describes the V5 universal screw clamp/mast system, not the requested articulated interchangeable-head system. Its original test pair is `00A_TEST_thread_nut_10x2p5_PRINT_FIRST.stl` and `00B_TEST_short_thread_screw_10x2p5.stl`. The existing `MAZ_10x2p5_thread_clearance_tests/README.txt` already proposes female clearances A=0.30, B=0.45, C=0.60 mm with the old male. Those labels alone do not establish whether the source treats clearance as radial or diametral; inspect geometry before reusing them. Do not assume that any variant was physically printed.

## Printed screw binding: what to change and test

Prusa explicitly says there is no universal fit tolerance: orientation, geometry, calibration, material and settings affect it. Their starting point of at least 0.3 mm for movable fits is a starting point, not proof for this custom thread. [Prusa design guidance](https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135)

The BOSL2 maintainers document printer-specific internal-thread clearance, beveled entrances and blunt starts/lead-ins; they explain that blunt starts make starting easier and avoid delicate partial ends. In BOSL2 specifically, `$slop` enlarges internal diameter by four times its value; do not transfer its number directly into unrelated CAD. [BOSL2 threading reference](https://github.com/BelfrySCAD/BOSL2/wiki/threading.scad)

Engineering recommendations and diagnostic hypotheses (not a confirmed diagnosis):

- Preserve the existing male's pitch, handedness, number of starts, and flank shape. Do not uniformly scale either part: that changes pitch.
- Reuse the existing 10x2.5 mm thread geometry if inspection shows it is sound. Add useful clearance locally to the female thread and an entrance chamfer/run-in. Use a through nut or adequate depth to distinguish binding from simple bottoming-out.
- Integrate this correction into the functional joint fastener test. Another generic screw tolerance plate is unnecessary; the existing three-nut set is historical evidence, not the new deliverable.
- Difficulty on the first turn can indicate damaged entrance, first-layer flare, or cross-threading. Gradual tightening along engagement can indicate insufficient flank clearance, seam interference, or pitch mismatch. An abrupt stop at a repeatable depth can indicate a blind-hole bottom/shoulder or local defect. Inspect the old pieces and the actual source before selecting a cause.
- Cool the parts before testing. Start straight using fingers; back up to locate the starting thread. Require full usable engagement by hand and repeated assembly without damaged crests. Do not treat force with pliers as a pass.

Orca's positive XY hole compensation enlarges holes; positive contour compensation enlarges outside contours. Elephant-foot compensation acts on the early layers. These are not interchangeable adjustments. Keep global hole/contour compensation at the already-calibrated value (otherwise zero for a CAD-clearanced plate), because a blanket change also alters the other fit tests. A 0.15 mm elephant-foot setting is a provisional starting value, not calibration evidence. [Orca precision documentation](https://www.orcaslicer.com/wiki/print_settings/quality/quality_settings_precision.html)

## Device geometry

| Device | Manufacturer dimensions | Bare mass | Design consequence |
| --- | --- | --- | --- |
| Pixel 8 | 150.5 x 70.8 x 8.9 mm | 187 g | Case, camera bar, screen lip, and buttons require actual fit testing; nominal body thickness is not a case specification. |
| Cardputer ADV | 84.0 x 54.0 x 19.6 mm | 81 g | Use ADV geometry, not the original Cardputer's envelope. |

Sources: [Google Pixel 8 specifications](https://store.google.com/us/product/pixel_8_specs?hl=en-US), [M5Stack Cardputer ADV documentation](https://docs.m5stack.com/en/core/Cardputer-Adv).

The ADV documentation identifies USB-C operation, G0 button/power switch, Grove, audio, microSD and expansion interfaces. Its dimensional drawing contains both 16 and 19.6 mm dimensions; do not assume every edge has the full overall thickness. Exact connector coordinates should come from the official structure model or physical measurement, not the overall envelope. [Official ADV dimensional PDF](https://m5stack-doc.oss-cn-shenzhen.aliyuncs.com/1178/K132-Adv-cardputer-ADV.pdf), [manufacturer structure files](https://github.com/m5stack/M5_Hardware/tree/master/Products/K132-Adv_Cardputer-Adv/Structures).

For a short grip coupon, test actual insertion, screen/key clearance, retention lip, and the real charging plug at the intended location. A short coupon cannot prove that a later full holder avoids every button; that remains dependent on final placement. Unknown phone-case thickness must be explicitly labeled as an assumption or covered by local adjustable geometry.

## Frame clip and indexed joint

The inspected local legacy design was a 32 mm universal clamp. It does not prove the target Ender frame's cross-section. No manufacturer dimensioned Ender-5 extrusion drawing was verified in this bounded search. A nominal 20 mm rail clip is an assumption until tested on the intended rail, including groove lips, nearby fasteners and carriage travel. Keep A/B/C as short sections differing in one known dimension and with removable tabs; do not make full mounts.

Ganter uses engaged serrated locking plates for angular positioning and a clamping mechanism to engage them. This supports the mechanism choice, not a load rating for printed PLA. [Ganter serrated-locking explanation](https://www.ganternorm.com/fileadmin/user_upload/presse/pressemitteilungen/press%20releases/2021-07_serrated_locking_plates_eng.pdf)

Engineering recommendation: face-indexed teeth held together with the printed screw. Loosen enough to disengage before changing angle, then retighten; do not drag ratchet teeth under full clamp force. Teeth face upward during printing, bore vertical, broad base down. Verify mating phase and tooth valley clearance in CAD and assembly; two identical tooth patterns require the correct angular offset.

The bare Pixel's static torque is `0.187 * 9.81 * reach_metres` N m: 0.183 N m at 100 mm, 0.367 N m at 200 mm, and 0.550 N m at 300 mm. These are calculations, not tested capacities. Include case, head and arm self-weight when defining the eventual requirement. A short lever with an increased dummy weight can produce equivalent torque: 1.0 kg at 50 mm gives 0.491 N m. First test over a soft surface with a dummy load. A short successful static test does not certify an overnight or fatigue lifetime.

PLA has limited temperature resistance and weaker layer bonding than some alternatives; Prusa reports deformation above roughly 60 C. This makes clip orientation and tooth engagement relevant near a working printer. Do not extrapolate room-temperature coupon results to a hot enclosure. [Prusa PLA material guidance](https://help.prusa3d.com/article/pla_2062)

## Plate and slicer recommendations

These are proposed initial settings; final export validation and actual slicing must confirm them:

- 0.4 mm nozzle assumption, 0.20 mm layer and first layer, 3 walls minimum (4 at loaded joint), 4 top/bottom layers, 15-20% rectilinear or gyroid infill. Thread/clip thin regions naturally become mostly walls.
- Use the already working PLA temperature/retraction profile. If absent, 210 C nozzle and 60 C bed are starting values, not printer-specific calibration.
- Flat intended bottoms at Z=0; thread axes vertical; open clip profiles on bed; teeth upward; separate connector halves. Supports off only after inspecting all layer previews for isolated islands and unsuitable bridges.
- Preserve 100% scale and designed arrangement. Print by layer, not sequential object mode. Keep physical gaps and a bed-edge margin; check brims and skirt as part of the 220 x 220 mm envelope.
- Initial outer walls 25 mm/s, other walls 40 mm/s, infill 50 mm/s, first layer 20 mm/s, conservative Ender acceleration. Do not speed up critical surfaces solely to meet 90 minutes.
- Report time and grams from actual slicer output when available, identifying the selected machine/filament profile. Mesh volume alone cannot accurately predict infill mass or travel/cooling time.

Stop after the compact test exports and validation. No complete arm until user reports physical results.
