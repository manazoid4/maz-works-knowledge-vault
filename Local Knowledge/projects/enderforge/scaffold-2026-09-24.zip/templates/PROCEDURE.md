---
record_type: procedure
schema_version: 1
status: draft
---
# Procedure title

## Outcome
TBD

## Required hardware, capabilities and starting state
TBD

## Read-only observations
TBD

## Proposed actions and physical checks
TBD: one action per step, with units and expected outcome.

## Stop conditions and recovery
TBD

## Evidence and exit criteria
TBD
