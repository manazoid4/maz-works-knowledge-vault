---
record_type: decision
date: TBD
status: proposed
---
# Decision title

## Problem and evidence
TBD

## Options and tradeoffs
TBD

## Decision and prerequisites
TBD

## Validation and rollback
TBD

## Sources and next review
TBD
