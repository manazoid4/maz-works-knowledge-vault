---
record_type: comparison
schema_version: 1
date: TBD
status: planned
---
# Before / after comparison

## Matched conditions

Printer/model/filament: TBD. Baseline run IDs: TBD. Tuned run IDs: TBD.
Changed variables: TBD. Uncontrolled differences/exclusions: TBD.
Timing boundary: TBD. Quality limits agreed before test: TBD.

| Metric | Baseline | Tuned | Difference |
|---|---|---|---|
| Completed/attempted runs | TBD | TBD | TBD |
| Median print-only seconds | TBD | TBD | TBD |
| Range seconds | TBD | TBD | TBD |
| Wall duration seconds | TBD | TBD | TBD |
| Configured speed mm/s | TBD | TBD | TBD |
| Configured acceleration mm/s² | TBD | TBD | TBD |
| Dimensional error mm | TBD | TBD | TBD |
| Stringing/blobs/ringing scores | TBD | TBD | TBD |

## Conclusion

Time saved: TBD %. Speedup: TBD ×. Use documented formulas, not slicer estimates.
Quality gate: TBD. Evidence sufficient or preliminary: TBD.
Chosen profile and rollback: TBD. No physical speed measurement claimed unless attached.
