# Markdown record formats

Copy a template; preserve headings so future parsers can migrate records. Use `TBD` for unknown values, never zero. Include units, provenance and date. Paths in an actual record must point to its real evidence.

- [RUN.md](RUN.md): one physical test execution, including failed runs.
- [COMPARISON.md](COMPARISON.md): a matched baseline/tuned result.
- [DECISION.md](DECISION.md): a reviewed choice and rollback.
- [PROCEDURE.md](PROCEDURE.md): a reusable guided calibration step.

File naming: `YYYY-MM-DD-test-id-run-NN.md`. Store prototype runs in `testing/ender-5/runs/`, comparisons in `testing/ender-5/results/`, reviewed setting snapshots in `testing/ender-5/settings/`.
