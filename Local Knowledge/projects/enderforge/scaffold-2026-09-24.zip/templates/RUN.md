---
record_type: calibration-run
schema_version: 1
run_id: TBD
printer_id: ender-5-prototype
date: TBD
status: planned
---
# Test run

## Purpose and controlled variable

Test ID: TBD. Hypothesis: TBD. Changed setting: TBD. Baseline run/profile: TBD.

## Setup and evidence

Firmware/build: TBD. Machine profile: TBD. Filament/spool/condition: TBD.
Nozzle: TBD mm. Slicer/version: TBD. Profile hash: TBD.
Model source/revision/SHA256: TBD. G-code SHA256: TBD.
Orientation/scale: TBD. Layer height/walls/infill/support: TBD.
Bed/nozzle target: TBD °C. Speeds: TBD mm/s. Acceleration: TBD mm/s².
Mechanical/homing prerequisites: TBD. Measurement tool/resolution: TBD.

## Timing

Source: TBD. Start/end with timezone: TBD. Wall duration: TBD seconds.
Heating: TBD seconds. Pauses: TBD seconds. Print-only duration: TBD seconds.
Slicer estimate (separate): TBD seconds. Completion/failure reason: TBD.

## Observations

X/Y/Z measured: TBD mm. Dimensional tolerance: TBD mm.
Stringing: TBD /3. Blobs: TBD /3. Ringing: TBD /3.
Adhesion, overhangs, bridging, bonding and material used: TBD.
Photos/logs/artifacts: TBD. Unexpected movement or skipped steps: TBD.

## Result and next action

Pass/fail/inconclusive: TBD. Keep/revert: TBD. Rollback evidence: TBD.
Next single change: TBD. Reviewer: TBD.
