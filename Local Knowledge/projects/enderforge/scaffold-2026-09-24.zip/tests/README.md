# tests

Future software tests: fake printer transport, workflow transitions, units, credential redaction, disconnect handling, report calculations and CLI/GUI parity. Physical calibration belongs in testing/. No runnable software test suite exists yet.
