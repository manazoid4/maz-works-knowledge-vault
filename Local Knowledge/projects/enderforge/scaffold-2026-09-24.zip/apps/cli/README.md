# apps/cli

Future CLI/TUI client. Implement the first read-only baseline capture slice here after choosing the stack. See ../../docs/UX.md. No executable application exists yet.
