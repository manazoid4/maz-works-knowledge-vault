# apps/gui

Future GUI client using the same workflow engine as the CLI. See ../../docs/PRODUCT.md for parity requirements. No runnable UI exists yet.
