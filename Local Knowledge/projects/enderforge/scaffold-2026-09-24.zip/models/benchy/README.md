# Benchy benchmark

Obtain the canonical model from the [official 3DBenchy download page](https://www.3dbenchy.com/download/). Model not bundled in this scaffold. Record exact source, download date, SHA256, scale and orientation in every run.

The creator/rights-holder [announced public-domain release](https://www.nti-group.com/home/news/3dbenchy/). Preserve the downloaded asset's provenance and terms before redistribution, including any source-specific variants. Do not substitute a modified speed Benchy without labelling it as a different test.

Use the same unmodified model for matched runs. Inspect hull, cabin, chimney, bridging and overhangs; record real duration and failures. No claim of a completed benchmark yet.
