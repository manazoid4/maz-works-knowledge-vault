// EnderForge original measurement fixture, dimensions in millimetres.
// Plain geometry avoids text relief affecting measurements.
cube([20, 20, 20], center = false);
