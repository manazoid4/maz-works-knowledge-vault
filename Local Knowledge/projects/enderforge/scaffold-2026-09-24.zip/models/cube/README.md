# 20 mm cube

Original plain 20 × 20 × 20 mm OpenSCAD source: [cube-20mm.scad](cube-20mm.scad). Export an STL using OpenSCAD before slicing; this scaffold has not rendered or printed it. Keep scale at 100%, record bed orientation and mark X/Y on the finished part after removal.

Measure at consistent positions away from the first-layer edge. Record caliper resolution and repeated measurements. Do not automatically alter XYZ steps to compensate for material shrinkage or extrusion defects.
