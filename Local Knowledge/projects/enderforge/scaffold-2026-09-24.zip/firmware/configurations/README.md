# firmware/configurations

Store reviewed source configuration, pinned release/build environment and config diffs here. No firmware configuration or binary is currently provided. See ../../docs/research/FIRMWARE.md.
