# firmware/backups

Store only reviewed backup manifests here. Keep firmware binaries and full service configurations outside Git. A settings report is not a firmware image backup. Record recovery image location, SHA256 and compatibility verification.
