# Interface direction

Reference: [Hermes Agent CLI](https://hermes-agent.nousresearch.com/docs/user-guide/cli), reviewed 2026-09-24. Inspiration is a keyboard-first conversational terminal experience, not copied branding or an agent dependency.

## Proposed terminal experience

- Persistent printer, connection, heater, job and current-step status.
- Plain-language prompt with discoverable actions and command completion.
- One physical instruction at a time, with explicit user observations.
- Proposed change card: old value, new value, units, reason and rollback.
- Scrollable session history, saved checkpoints and a final comparison report.

Illustrative commands, not implemented: `enderforge connect`, `baseline capture`, `calibrate`, `benchmark compare`, `profile export`. Illustrative TUI actions: `/status`, `/next`, `/back`, `/report`, `/help`.

## GUI parity

Provide the same actions as visible controls, accessible keyboard navigation and text-labelled state. Show progress, machine status, diagrams for physical checks, before/after evidence and a clear stop control. Never hide a firmware write behind a generic Next button. A user should not need G-code knowledge for ordinary calibration.
