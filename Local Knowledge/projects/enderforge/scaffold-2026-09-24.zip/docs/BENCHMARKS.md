# Benchmark protocol

## What we measure

1. **Configured speeds:** slicer feature speeds and firmware maximum feedrates, in mm/s. G-code F values are generally mm/min; retain raw values and convert explicitly.
2. **Configured acceleration:** print/travel/retract acceleration and axis caps in mm/s². Record junction deviation or classic jerk separately with the correct mode and units.
3. **Actual duration:** wall-clock start-to-finish and printing-only duration, plus heating, pauses and failure state. Record clock/event source and missing events.
4. **Quality:** dimensions, stringing, blobs, ringing, adhesion, bridges/overhangs and functional fit.

Commanded feedrates and slicer estimates are not measured physical toolhead speed. Short moves, acceleration, firmware caps, cooling and volumetric flow can prevent reaching requested speed. Do not label an estimate as measured speed; external measurement is optional future work.

## Matched before/after experiment

- Establish safe mechanics/homing before printing any baseline; document pre-repair observations separately.
- Use identical model revision/hash, scale, orientation, layer height, nozzle, walls, infill, support, filament/spool condition and test location. Record machine/firmware/slicer revisions.
- Change one variable or explicitly named group. Save both profiles and G-code hashes; settings experiments normally produce different G-code.
- Record start/end events, pauses, warm-up policy, material consumption and ambient conditions where available.
- Aim for three completed runs per condition; show individual runs, median and range. One run is preliminary. Keep failures visible, never omit them to improve averages.
- Compare only completed, valid runs with the same timing boundary. Report firmware or mechanical changes as separate conditions.

Time saved (%) = 100 × (baseline median seconds − tuned median seconds) / baseline median seconds.
Speedup factor = baseline median seconds / tuned median seconds. Baseline must be positive. Negative savings are regressions. Do not confuse 20% time saved with 20% higher physical speed.

## Quality gate

Before a sweep, agree dimensional tolerance, maximum acceptable defect scores and no-layer-shift/no-skipped-step conditions. No universal speed or acceleration target is promised. Rate stringing, blobs and ringing independently: 0 none, 1 slight, 2 clearly visible, 3 severe/unusable. Use fixed lighting/view and the same evaluator; subjective scores are not precision instruments.

Cube: measure X/Y/Z at repeatable locations with a recorded tool and resolution. A cube alone cannot distinguish motion scale, flow and material shrinkage. Benchy: inspect hull, cabin, chimney, bridges and overhangs using the same model; it is a whole-system check, not an isolated diagnosis.

## Test order

Mechanical checklist -> first-layer patches -> extrusion/flow -> temperature -> retraction -> acceleration/ringing -> speed/flow limit -> cube and Benchy validation. Stop sweeps on adhesion loss, severe underextrusion, layer shift or abnormal motion. Return to the last documented stable setting.
