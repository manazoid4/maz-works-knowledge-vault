# Product definition

## Problem

Printer owners have settings scattered across firmware, slicers and terminal commands. They need a guided way to identify the cause of poor prints, tune safely, and prove whether a change helped. This project began after an Ender 5 was moved during a print and its Z screw was manually turned. The print was cancelled; no successful recovery or calibration is claimed.

## Users and prototype

First user: the owner's Ender 5 through OctoPrint. Later: owners of supported Cartesian FDM printers, each with independent machine and filament profiles. Start local, with manual observations and no mandatory probe, camera, cloud account or paid AI service.

## MVP acceptance

- A new user can connect to OctoPrint, identify supported capabilities and save a redacted baseline without moving or heating the printer.
- CLI/TUI and GUI share the same resumable sequence: inspect mechanics, verify homing, tram manually, validate first layer, tune extrusion and quality, then speed/acceleration.
- Each step explains the action, units, expected observation and rollback; unsupported commands are blocked with a useful reason.
- A user can prepare approved cube and Benchy tests for their own profile, record results and compare matched before/after runs.
- Reports show actual duration, configured speed/acceleration, quality scores and provenance separately. No measured toolhead-speed claim without a measurement source.
- A saved session resumes at a trustworthy checkpoint after disconnect, rather than blindly replaying motion or extrusion.
- An owner can export/import a profile and report without disclosing credentials. Both interfaces complete the same prototype workflow.

## Automation boundary

Automate reading capabilities, capturing settings, preparing proposed changes, collecting job timing, recording results and producing comparisons. Guide the user through bed knob adjustment, paper/feeler checks, mechanical inspection and print measurement. Manual mesh is optional and only offered for a verified firmware capability. A program cannot infer bed position from motor counters after someone turns the screw.

The core must work deterministically. Optional conversational assistance may explain results later, but it must not bypass validated workflows or generate unchecked machine commands.

## Later work

Guided filament unload/load/purge, multi-printer support, richer diagnostics and optional premium conveniences follow the prototype. Core safety, backups and access to personal calibration data must remain available without a premium subscription. Pricing, licensing and distribution are open decisions.
