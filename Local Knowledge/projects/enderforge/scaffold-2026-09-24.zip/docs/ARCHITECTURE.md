# Planned architecture

No stack is committed yet. Proposed direction: a local shared workflow service with a terminal client and a GUI client. Choose frameworks after a small connection/session prototype, not before.

## Components

- **Connection adapter:** OctoPrint first; direct serial later, exclusively owned. Capture capabilities and redact secrets.
- **Workflow engine:** explicit states, prerequisites, units, permissible actions, checkpoints and recovery. No arbitrary model-generated G-code execution.
- **Profiles:** separate machine hardware, firmware capabilities, filament properties and slicer settings. Versioned and validated, with unknowns preserved.
- **Sessions:** baseline snapshot, proposed/accepted changes, command acknowledgements, human observations and evidence references.
- **Benchmark/report engine:** matched run groups, actual timings, quality gates and transparent calculations.
- **CLI/TUI and GUI:** both call the same engine; neither implements separate machine-control rules.

## State and ownership

Disconnected -> identified -> baseline saved -> physically checked -> action ready -> executing -> observed -> reviewed -> checkpointed.

A disconnect, unexpected firmware response, manual axis movement or printer restart invalidates position assumptions. Reconnection must reconcile actual job state and require necessary physical checks; never replay queued motion automatically. Separate Cancel, Pause and emergency-stop semantics, and explain heater/motor consequences before action. Emergency-stop transport is not guaranteed on a failed connection; local printer access remains necessary.

## Data contract

IDs: printer, profile version, firmware build, session, test case, run and comparison. Every numeric observation includes units, source and time. Reports reference model and G-code hashes, slicer version, quality rubric and baseline/after run IDs. See the Markdown templates as the initial human-readable contract; formal schemas follow during implementation.

## Secrets and licensing

Use local credential storage; redact logs and exports. Only reviewed report artifacts belong in Git. Evaluate dependency and model licences before distribution; proprietary premium plans do not remove firmware licence obligations.
