# Ender 5 firmware decision

Verified research date: 2026-09-24. **Research only; nothing flashed.**

## Findings

User reports Marlin 2.0.7 and a BTT “SKR E3 V2” board. We provisionally interpret this as SKR Mini E3 V2.0; confirm the printed board designation and MCU before choosing a build.

[Marlin 2.1.2.8](https://github.com/MarlinFirmware/Marlin/releases/tag/2.1.2.8) is the official latest stable release identified by the release page and GitHub latest-release API. Its [matching configuration branch](https://github.com/MarlinFirmware/Configurations/tree/release-2.1.2.8) exists. Some cached download pages still show 2.1.2.7. Recheck at build time. Avoid selecting a beta/bugfix branch merely because its version number is higher.

The [BTT V2.0 firmware notes](https://github.com/bigtreetech/BIGTREETECH-SKR-mini-E3/blob/master/firmware/V2.0/README.md) list different Ender 5 and BLTouch binaries. These are useful vendor references, not proof that a binary matches this machine or is current. Do not use an Ender 3 build simply because it supports the board.

## Proposed decision

Evaluate a pinned, reproducible Marlin 2.1.2.8 build for the verified Ender 5 hardware. Stay on current firmware until inventory, backup and configuration review are complete. A newer version alone does not establish faster or better prints. Klipper is a later architecture option, not required for this prototype.

## Before building or flashing

- Capture firmware identification/capabilities (M115), current settings (M503), endstop state (M119) and slicer profile. These reports are not a full firmware backup.
- Confirm exact board/MCU/build environment, Ender 5 geometry, axis directions, endstop locations/polarity, Z lead and steps, drivers, motor currents, display and serial settings.
- Confirm thermistors, heaters, hotend temperature limit, extruder type, fans, nozzle and whether a probe exists. Preserve thermal protection.
- Review source and feature support for no-probe tramming/manual mesh. Do not assume that every G29 implementation uses the same parameters.
- Obtain a known-compatible recovery image or reproducible old build; retain configuration sources, dependency versions, hashes and an SD recovery procedure.
- Build without flashing, inspect warnings/size and review configuration differences. Separate supervised flash step with clear bed and local operator.
- After flash, verify temperature readings, endstop states, axis directions and supervised homing before any print. Review EEPROM migration rather than blindly loading old settings or resetting everything.

## No-probe levelling

Marlin documents [manual mesh levelling](https://marlinfw.org/docs/gcode/G029-mbl.html), using paper or a feeler gauge with human adjustment. Feature availability and commands must match the selected build. [Probe configuration docs](https://marlinfw.org/docs/configuration/probes.html) also describe evolution toward manual probing with other levelling modes, so do not hard-code one implementation across versions.

## Decision record to complete

Selected version/commit: TBD. Board identity: unverified. Build environment: TBD. Config review: pending. Recovery image: unavailable. Flash authorisation/date: not scheduled. Post-flash checks: not run.
