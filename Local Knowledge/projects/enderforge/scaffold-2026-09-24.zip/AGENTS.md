# EnderForge working rules

- Read README, tasks/todo.md and the selected printer's baseline before work.
- Use `agents/{task-slug}` branches and PRs; never push changes directly to main.
- Scope now: documentation and prototype calibration planning. No application is implemented.
- Mark each value as user-reported, observed, measured, proposed or unknown. Include units and dated evidence.
- Keep printer identity, firmware revision, slicer settings and filament linked to each run. Never apply one printer's numbers to another automatically.
- An old M114 position is not physical position evidence after manual movement, power loss or motor release.
- OctoPrint owns the serial connection when connected. Never open a competing serial client.
- Verify machine identity, empty bed/clear travel, homing and endstops before motion. Ask for physical observations where software cannot know.
- Never flash firmware, home, heat, start a print, write EEPROM or change limits as part of a read-only inventory.
- Review motion/settings changes and rollback before applying. Firmware flashing is a separate supervised workflow.
- Keep experimental settings volatile until validated; avoid repeated EEPROM writes.
- Do not fix shrinkage or extrusion errors by blindly changing XYZ steps from a cube measurement.
- Never commit API keys, complete OctoPrint configuration, Wi-Fi details or unreviewed serial logs.
- Update unified memory and the vault after meaningful work. Keep local observations out of public examples.
- Docs-only changes need link/template validation, not an invented application build. Once runnable software exists, document its real test/build commands.
