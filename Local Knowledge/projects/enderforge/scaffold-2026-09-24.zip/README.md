# EnderForge

Guided 3D printer calibration: faster, cleaner, more repeatable prints from the hardware you already own.

**Status: planning scaffold, not a working printer-control application.** The prototype is an Ender 5 with a user-reported BTT SKR Mini E3 V2.0 board and Marlin 2.0.7. Exact board marking and firmware identification still need verification. No bed-levelling sensor purchase is required.

## Outcomes

- Fix mechanical alignment and inconsistent first layers.
- Reduce stringing, blobs and ringing.
- Tune acceleration and usable print speeds without sacrificing agreed quality.
- Measure before/after results using repeatable cube, Benchy and targeted tests.
- Turn the proven workflow into a CLI/TUI and GUI that other printer owners can customise.

## Start here

1. [Product scope and MVP](docs/PRODUCT.md)
2. [Roadmap](docs/ROADMAP.md) and [next tasks](tasks/todo.md)
3. [Ender 5 hardware record](testing/ender-5/HARDWARE.md)
4. [Baseline worksheet](testing/ender-5/BASELINE.md)
5. [Firmware research](docs/research/FIRMWARE.md)
6. [Benchmark protocol](docs/BENCHMARKS.md)
7. [Markdown templates](templates/README.md)

## Repository map

| Folder | Purpose |
|---|---|
| `apps/cli`, `apps/gui` | Future user interfaces; specifications only |
| `core`, `integrations` | Planned workflow engine and printer connections |
| `profiles`, `workflows` | Printer/filament profiles and calibration procedures |
| `models` | Test model sources and provenance |
| `firmware` | Configuration review, backups and reproducible build records |
| `testing/ender-5` | This printer's hardware, baseline, runs and results |
| `tests` | Future software tests, separate from physical print tests |
| `templates` | Consistent Markdown records |
| `docs`, `tasks` | Product decisions, research and implementation plan |

Credentials, raw service configs, firmware binaries and large print artifacts stay out of Git by default. Store reviewed settings and hashes, not API keys. No executable control code or install command exists yet.

Working name: EnderForge. Repository visibility: private. Product licensing and pricing remain undecided.
Guided 3D printer calibration, repeatable benchmarks, and a planned CLI/TUI + GUI. Ender 5 prototype; no bed probe required.
