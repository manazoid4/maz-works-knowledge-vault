# core

Future shared workflow, session, profile and comparison logic. Keep machine actuation behind validated state transitions. See ../docs/ARCHITECTURE.md.
