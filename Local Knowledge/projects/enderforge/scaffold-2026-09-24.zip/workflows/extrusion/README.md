# workflows/extrusion

Planned extruder measurement, material temperature/flow and retraction workflows. Separate steps calibration from slicer flow and preserve the method used.
