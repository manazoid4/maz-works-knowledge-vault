# workflows/mechanical

Planned mechanical inspection and alignment procedure. Start from the Ender 5 test plan and the procedure template. Require human observations; no automatic motion yet.
