# workflows/performance

Planned acceleration, ringing, speed and volumetric-flow sweeps. Use agreed quality limits and repeatable timings; no universal performance target.
