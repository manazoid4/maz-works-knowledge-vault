# workflows/bed-levelling

Planned manual tramming and optional capability-gated manual mesh. No probe purchase required. Physical adjustment and nozzle-clearance checks need user feedback.
