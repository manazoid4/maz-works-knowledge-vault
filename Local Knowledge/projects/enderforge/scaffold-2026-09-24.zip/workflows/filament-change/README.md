# workflows/filament-change

Later roadmap work: identify material/hotend/extruder, guide heating, unload/load and purge, then verify extrusion. Standalone changes first. Mid-print support needs firmware-specific state preservation and recovery.
