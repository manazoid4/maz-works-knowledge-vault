# Implementation plan

Current delivery: documentation scaffold only. Physical calibration and product implementation are later tasks.

## 1. Capture a trusted inventory

Files: prototype HARDWARE.md, BASELINE.md, reviewed settings snapshot.
Acceptance: exact board identity confirmed; firmware/settings reports retained without secrets; unknowns explicit.
Verification: compare report fields with machine and slicer; no motion or settings writes during collection.
Dependency: none.

## 2. Decide firmware path

Files: firmware research, decision record, configuration README.
Acceptance: supported release/config selected or current firmware retained; source/build pinned; recovery route exists before any flash.
Verification: configuration diff and build evidence; supervised checks only if a flash is separately undertaken.
Dependency: 1. Checkpoint: inventory/firmware record reviewed.

## 3. Establish mechanical and first-layer baseline

Files: physical test plan, run record, baseline worksheet.
Acceptance: no binding/loose play, valid homing, consistent first layer.
Verification: operator observations and targeted print evidence.
Dependency: 1–2.

## 4. Tune quality, then performance

Files: individual run records, comparison, selected profile.
Acceptance: stringing/blobs improved; acceleration/speed selected within quality limits; repeat timings recorded.
Verification: targeted tests plus matched cube/Benchy runs.
Dependency: 3. Checkpoint: physical workflow is repeatable.

## 5. Deliver CLI baseline capture slice

Files: connection adapter, engine/session module, CLI entry point, focused tests, user guide.
Acceptance: connect, identify, capture and export without actuation or secret leakage.
Verification: fake transport tests, timeout/auth cases and read-only prototype check.
Dependency: 1 and architecture decision.

## 6. Deliver one guided workflow and report

Files: workflow definition, engine state transitions, CLI view, report module, focused tests.
Acceptance: user can complete and resume one manual calibration with recorded observations and a comparison.
Verification: fake acknowledgements/disconnects plus supervised end-to-end test.
Dependency: 4–5. Extend one verified workflow at a time.

## 7. Deliver GUI parity and package MVP

Files: GUI shell, workflow view, report view, install guide, E2E tests.
Acceptance: same workflow, profiles and stop/recovery behaviour in both interfaces.
Verification: full prototype flow in each interface, export round-trip and fresh-install check.
Dependency: 6. Checkpoint: MVP criteria in PRODUCT.md met.

## Open decisions

Hardware details, tolerances, implementation stack, licensing, packaging, model acquisition and pricing remain open. Do not block the documentation scaffold on these.
