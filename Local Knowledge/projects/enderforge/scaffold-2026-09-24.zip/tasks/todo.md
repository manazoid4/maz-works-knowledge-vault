# Next tasks

- [x] Create private repository, baseline templates and product roadmap.
- [x] Research current stable Marlin release and vendor board references.
- [ ] Confirm board marking, firmware report and printer modifications.
- [ ] Capture reviewed firmware settings and current slicer profile.
- [ ] Decide firmware keep/upgrade path and prepare rollback.
- [ ] Check mechanics, homing and first layer.
- [ ] Run quality calibration, then speed/acceleration experiments.
- [ ] Complete repeatable cube/Benchy before/after report.
- [ ] Implement read-only CLI connection/session slice.
- [ ] Implement guided workflow, profiles and report engine.
- [ ] Add GUI parity, recovery tests and packaging.
- [ ] Add guided filament change after MVP validation.
- [ ] Explore multi-printer beta and premium scope later.

GitHub Projects board creation is unavailable with the current token scopes. Use repository issues and this file; do not silently request broader credentials.
