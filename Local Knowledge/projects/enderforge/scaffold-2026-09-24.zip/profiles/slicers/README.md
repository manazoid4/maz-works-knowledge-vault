# profiles/slicers

Reviewed slicer exports and conversion notes go here. Keep credentials and machine-specific host addresses out of shared exports. Pin slicer version and hash.
