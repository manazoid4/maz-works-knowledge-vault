# profiles/filaments

Filament profiles go here, separated by material/spool where useful. Record nozzle, temperature, flow, volumetric limit, cooling and retraction evidence. Do not assume one PLA profile fits every spool.
