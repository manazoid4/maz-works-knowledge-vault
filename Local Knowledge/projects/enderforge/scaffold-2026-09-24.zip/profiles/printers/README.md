# profiles/printers

Reviewed reusable machine profiles go here. Include hardware identity, firmware capabilities, units, provenance and conservative supported ranges; unknowns must remain explicit.
