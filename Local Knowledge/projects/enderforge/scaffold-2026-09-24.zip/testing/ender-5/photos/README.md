# testing/ender-5/photos

Optional labelled visual evidence. Use consistent lighting and angles; exclude private surroundings. No camera is required for the core workflow.
