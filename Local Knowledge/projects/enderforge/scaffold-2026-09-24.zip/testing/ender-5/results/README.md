# testing/ender-5/results

Copy ../../../templates/COMPARISON.md for matched comparisons. No measurements or improvement claims exist yet.
