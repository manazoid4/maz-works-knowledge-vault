# testing/ender-5/artifact-manifests

Record model/G-code hashes, source locations and profile IDs. Large artifacts remain local or in an explicitly selected artifact store.
