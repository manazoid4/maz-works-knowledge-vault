# Physical test plan

| ID | Test | What it establishes | Evidence / gate |
|---|---|---|---|
| E5-01 | Mechanical inspection | Frame, bed support, wheels, belts and Z travel | Checklist; no binding or loose play |
| E5-02 | Endstops and supervised homing | Correct directions, trigger locations and travel | Observations and firmware identity |
| E5-03 | Manual tram and first-layer patches | Consistent clearance and adhesion | All sampled regions acceptable |
| E5-04 | Extrusion measurement | Commanded vs measured filament feed | Measurement method, repeatability, no slip |
| E5-05 | Temperature and flow | Stable extrusion and useful material settings | Test results, surface and bonding observations |
| E5-06 | Retraction/stringing | Retraction effects separated from temperature/moisture | Matched observations and 0–3 scores |
| E5-07 | Acceleration/ringing sweep | Highest acceptable acceleration under test conditions | No shifts; ringing within agreed limit |
| E5-08 | Speed/flow sweep | Useful speed constrained by extrusion and quality | No underextrusion/adhesion failure |
| E5-09 | 20 mm cube | Dimensional and surface validation | Measured X/Y/Z; repeat run IDs |
| E5-10 | Benchy | Whole-print quality and duration | Paired before/after runs and report |

Use [BENCHMARKS.md](../../docs/BENCHMARKS.md). A cube and Benchy do not replace targeted tests. Freeze test conditions before comparing; select numeric tolerances with the owner after tool capability is known.
