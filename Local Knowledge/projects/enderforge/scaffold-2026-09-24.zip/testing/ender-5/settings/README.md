# testing/ender-5/settings

Reviewed M115/M503/M119 transcripts and slicer-setting snapshots belong here after collection. Strip host credentials and private identifiers. Include timestamps and raw units.
