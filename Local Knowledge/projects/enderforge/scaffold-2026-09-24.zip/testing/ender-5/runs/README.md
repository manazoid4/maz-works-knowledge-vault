# testing/ender-5/runs

Copy ../../../templates/RUN.md for each physical attempt. Include failed attempts; do not populate fabricated baseline measurements.
