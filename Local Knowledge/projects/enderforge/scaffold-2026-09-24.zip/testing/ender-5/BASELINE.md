# Ender 5 baseline worksheet

Status: **not measured**. Date: TBD. Operator: TBD. Hardware record: [HARDWARE.md](HARDWARE.md).

| Setting / measurement | Baseline | Tuned | Units / source |
|---|---|---|---|
| Firmware/build ID | 2.0.7 reported | TBD | M115 + build hash |
| X/Y/Z/E steps | TBD | TBD | steps/mm, M503 |
| X/Y/Z/E maximum feedrate | TBD | TBD | mm/s, firmware |
| X/Y/Z/E acceleration caps | TBD | TBD | mm/s², firmware |
| Print / travel / retract acceleration | TBD | TBD | mm/s², firmware + slicer |
| Junction mode and value | TBD | TBD | classic jerk mm/s OR junction deviation mm |
| Linear advance / input shaping capability | TBD | TBD | supported? parameters + units |
| Outer / inner / infill speed | TBD | TBD | mm/s, slicer |
| First layer / travel speed | TBD | TBD | mm/s, slicer |
| Speed / flow overrides | TBD | TBD | %, printer |
| Nozzle / bed temperatures | TBD | TBD | °C, profile and telemetry |
| Flow ratio / max volumetric flow | TBD | TBD | ratio / mm³/s, filament profile |
| Retraction length / speed | TBD | TBD | mm / mm/s |
| Cooling / minimum layer time | TBD | TBD | % / seconds |
| Layer height / line width | TBD | TBD | mm |
| Bed tram / mesh / clearance method | TBD | TBD | procedure + evidence |
| Cube median print-only duration | TBD | TBD | seconds, run IDs |
| Benchy median print-only duration | TBD | TBD | seconds, run IDs |
| X/Y/Z dimensional error | TBD | TBD | mm, tool + locations |
| Stringing / blobs / ringing | TBD | TBD | separate 0–3 scores |
| Completed / attempted prints | TBD | TBD | counts, including failures |

Earlier job targets of 220°C/60°C are observations of the abandoned job, not calibrated recommendations. No speed, acceleration or quality improvement has been measured yet.

## Before taking baseline prints

- [ ] Save reviewed firmware/settings and slicer exports.
- [ ] Resolve mechanical movement and homing issues first.
- [ ] Agree model, timing boundaries and quality tolerances.
- [ ] Record a fresh run using [RUN.md](../../templates/RUN.md).
