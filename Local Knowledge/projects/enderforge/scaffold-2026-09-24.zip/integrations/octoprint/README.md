# integrations/octoprint

Future OctoPrint adapter. Read status first, use existing authentication securely, and handle asynchronous acknowledgements. Never log credentials. OctoPrint must retain sole ownership of serial while connected.
