# integrations/serial

Reserved for a later exclusive direct-serial adapter. Do not connect while OctoPrint owns the port. Reconnect requires state reconciliation.
